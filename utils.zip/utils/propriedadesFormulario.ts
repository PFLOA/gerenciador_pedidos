/* eslint-disable no-shadow */

export enum PropriedadesFormularios {
	Telefone = 'telefone',
	Cpf = 'cpf',
	Email = 'email',
	Money = 'preco',
}
